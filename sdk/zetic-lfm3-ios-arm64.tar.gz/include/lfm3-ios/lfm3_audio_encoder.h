#pragma once
#include "coreml_runner.h"
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace lfm3_ios {
// Synchronous module seam; the default implementation wraps CoreMlRunner.
class AudioModule {
 public:
  virtual ~AudioModule() = default;
  virtual bool run(const std::vector<InputTensor>& inputs,
                   std::vector<OutputTensor>& outputs, std::string& error) = 0;
};
struct AudioFeatures {
  std::vector<float> values; // [rows, 2048], FP32
  int32_t mel_frames = 0, rows = 0;
  double preprocess_seconds = 0, encoder_seconds = 0;
};
// The caller must verify model package identity before passing paths. Inputs
// must be decoded mono 16 kHz PCM; this does not decode or resample audio.
class AudioEncoder {
 public:
  bool load(const std::string& preprocess_package, const std::string& encoder_package,
            std::string& error);
  bool initialize(std::unique_ptr<AudioModule> preprocess,
                  std::unique_ptr<AudioModule> encoder, std::string& error);
  bool encode(const float* pcm, size_t samples, AudioFeatures& out, std::string& error);
  static int32_t melFrames(size_t samples);
 private:
  std::unique_ptr<AudioModule> preprocess_, encoder_;
};
}
