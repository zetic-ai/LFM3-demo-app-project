#pragma once
#include "lfm3_audio_encoder.h"
#include "text_generation.h"
#include <cstddef>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
namespace lfm3_ios {
struct AudioTextRequest {
  const float* pcm = nullptr; size_t samples = 0; // mono FP32, 16 kHz, <=30s
  std::string system = "Perform ASR in English.";
  std::string user_text; // optional text before the audio embedding rows
  size_t max_tokens = 256;
  bool stop_at_eos = true; // false permits fixed-count speed diagnostics
  std::vector<std::string> stop_strings;
};
struct AudioTextResult {
  size_t generated = 0, audio_rows = 0, prompt_rows = 0;
  double preprocess_seconds = 0, encoder_seconds = 0;
  GenerationFinish finish = GenerationFinish::TokenLimit;
};
// Matches the measured Audio prefix/suffix contract. No extra BOS/EOS is
// inserted by tokenization; the prefix explicitly contains the BOS marker.
void renderAudioPrompt(const std::string& system, const std::string& user_text,
                       std::string& prefix, std::string& suffix);
// One synchronous non-reentrant session. Source identity is pinned to the
// published Audio checkpoint and selected mixed-FP16/GPTQ release recipe.
class AudioTextSession {
 public:
  AudioTextSession(); ~AudioTextSession();
  AudioTextSession(const AudioTextSession&)=delete;
  AudioTextSession& operator=(const AudioTextSession&)=delete;
  bool open(const std::string& bundle, const std::string& expected_package_id, std::string& error);
  bool generate(const AudioTextRequest& request,
                const std::function<bool(std::string_view)>& on_chunk,
                AudioTextResult& result, std::string& error,
                const std::function<void(int32_t,size_t)>& on_token = {});
  std::string packageId() const;
  TextRoute selectedRoute() const;
 private:
  struct Impl; std::unique_ptr<Impl> impl_;
};
}
