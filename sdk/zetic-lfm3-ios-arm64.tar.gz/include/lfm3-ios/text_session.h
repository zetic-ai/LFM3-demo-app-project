#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace lfm3_ios {

struct TextOptions {
  // The previous iPhone Text benchmark used these per-channel tiles.
  // The route is instance-local and unsupported configurations fail to load.
  std::string w13 = "r1s4_exact";
  std::string w2 = "r1s4_exact";
  bool defer_metal_weights = false;
  // Optional steady-clock nanosecond load intervals, reported after completion.
  std::function<void(const char*, uint64_t, uint64_t)> on_model_load;
  std::function<void(const char*, uint64_t, uint64_t)> on_setup;
};

struct TextRoute {
  std::string engine;
  std::string w13;
  std::string w2;
  bool gpu_greedy = false;
};

// Consecutive media embeddings replace token rows starting at `first_row`.
// The caller is responsible for matching token placeholders and model weights.
struct MediaEmbeddingSpan {
  size_t first_row = 0;
  std::vector<float> values;  // [row_count, hidden_size]
};

// Experimental, token-ID-only LFM3 text path. This owns the model and state,
// performs synchronous work, and must be used from a single worker thread.
// Tokenization and chat/generation helpers are provided by the optional
// lfm3_ios_tokenizer target; this API itself accepts token IDs.
// Numerical and performance equivalence to the Ixian route is not established.
class TextSession {
 public:
  TextSession();
  ~TextSession();
  TextSession(const TextSession&) = delete;
  TextSession& operator=(const TextSession&) = delete;

  bool open(const std::string& model_directory, std::string& error);
  bool open(const std::string& model_directory, const TextOptions& options,
            std::string& error);
  TextRoute selectedRoute() const;
  std::string packageId() const;
  // Zero means the session has not successfully opened a model.
  size_t prefillCapacity() const;
  size_t contextCapacity() const;
  // Starts a fresh context. Logits predict the token following the input.
  bool prefill(const std::vector<int32_t>& token_ids,
               std::vector<float>& logits, std::string& error);
  bool prefillWithMedia(const std::vector<int32_t>& token_ids,
                        const std::vector<MediaEmbeddingSpan>& media,
                        std::vector<float>& logits, std::string& error);
  // Feed one chosen token and obtain logits for the next token.
  bool decode(int32_t token_id, std::vector<float>& logits, std::string& error);
  // Omni speech requires the normalized hidden state after accepting either a
  // language token or one external feedback row. These synchronous methods
  // use the ordinary Metal path and must not overlap a greedy stream.
  bool decodeWithHidden(int32_t token_id,std::vector<float>& logits,
                        std::vector<float>& hidden,std::string& error);
  bool decodeEmbedding(const std::vector<float>& embedding,std::vector<float>& logits,
                       std::vector<float>& hidden,std::string& error);
  // One-shot memory mode: release prefill after its state has been consumed.
  bool retirePrefill(std::string& error);
  bool materializeMetal(std::string& error);
  // Greedy continuation: begin with the token selected from prefill logits.
  // nextGreedy returns that first token before later GPU-selected tokens.
  // kept is the number of returned tokens accepted, including the first;
  // the Metal executor handles one speculative step when ending. Selecting
  // the measured per-channel route/tiles is controlled by TextOptions at
  // open(). These APIs reject unsupported
  // routes instead of falling back to scalar decode.
  bool beginGreedy(int32_t first_token, std::string& error);
  bool beginGreedy(int32_t first_token, const std::vector<int32_t>& suppress_ids,
                   std::string& error, bool validate_finite = false);
  bool nextGreedy(int32_t& token, std::string& error);
  bool endGreedy(size_t kept, std::string& error);
  void reset();

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace lfm3_ios
