#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace lfm3_ios {

enum class ScalarType { Fp16, Fp32, Int32 };

// Input storage is owned by the caller and must remain valid until run returns.
// Shapes and byte counts are checked against the model's actual input contract.
struct InputTensor {
  std::string name;
  ScalarType type;
  std::vector<int64_t> shape;
  const void* data = nullptr;
  size_t bytes = 0;
};

struct OutputTensor {
  std::string name;
  ScalarType type;
  std::vector<int64_t> shape;
  std::vector<uint8_t> data;  // packed row-major, irrespective of Core ML strides
};

// Directory-based Core ML runner, synchronous and non-reentrant. It accepts a
// source .mlpackage or an already compiled .mlmodelc. Call on a worker thread.
// First-load compilation and caching policy are not part of inference timing.
class CoreMlRunner {
 public:
  // Empty cache_directory selects the app Caches directory.
  explicit CoreMlRunner(const std::string& cache_directory = {});
  ~CoreMlRunner();
  CoreMlRunner(const CoreMlRunner&) = delete;
  CoreMlRunner& operator=(const CoreMlRunner&) = delete;
  bool load(const std::string& path, std::string& error);
  void unload();
  // Removes recreatable cache entries. Returns false if another model is active.
  static bool clearCompiledCache(const std::string& cache_directory, std::string& error);
  bool run(const std::vector<InputTensor>& inputs,
           std::vector<OutputTensor>& outputs, std::string& error);

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
  std::string cache_directory_;
};

}  // namespace lfm3_ios
