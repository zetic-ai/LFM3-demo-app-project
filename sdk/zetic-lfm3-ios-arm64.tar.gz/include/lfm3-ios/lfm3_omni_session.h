#pragma once
#include "lfm3_omni_bundle.h"
#include <cstddef>
#include <array>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <vector>
namespace lfm3_ios {
struct OmniRequest {
  std::string system_prompt,user_text;
  std::vector<float> pcm_samples;  // optional mono FP32 16 kHz, <=30s
  std::vector<uint8_t> rgb;       // optional oriented/resized RGB8 512x512
};
enum class OmniSpeechMode { Audio, Interleaved };
enum class OmniStopReason { EndOfSequence, Cancelled, GenerationBudget, ContextCapacity, Error };
struct OmniOptions {
  OmniSpeechMode mode=OmniSpeechMode::Audio;
  size_t max_generation_steps=0; // 0: remaining context
  float temperature=0.4f,repetition_penalty=1.2f;
  size_t repetition_window=64;uint64_t seed=0;
  size_t codec_chunk_frames=1;bool collect_audio=true;
  std::function<bool()> cancelled;
  // Completed load intervals in steady-clock nanoseconds (same epoch as monotonicNanoseconds).
  // Exclude their union only; keep full wall time and other setup overhead separately.
  std::function<void(const char*,uint64_t,uint64_t)> on_model_load;
  // Separate from model load: e.g. full bundle verification.
  std::function<void(const char*,uint64_t,uint64_t)> on_setup;
  // Actual selected Metal route after materialization (greedy may be false for speech).
  std::function<void(const std::string&,const std::string&,const std::string&,bool)> on_route;
  // Optional diagnostic observer: called for each sampled frame, including
  // an EOS frame, before codec submission; count is one-based generation step.
  std::function<void(const std::array<int32_t,12>&,size_t,bool)> on_speech_frame;
  // Optional diagnostics; media placeholders are expanded to their real rows.
  std::function<void(const std::vector<int32_t>&)> on_prompt;
};
struct OmniResult {
  std::string text;std::vector<float> pcm_samples;
  int32_t sample_rate=24000;size_t audio_frames=0,generation_steps=0,prompt_rows=0;
  OmniStopReason stop_reason=OmniStopReason::Error;std::string error;
};
// Synchronous one-shot runner. Modules are loaded in stages during each
// request; timings measured around respond include those loads. Callback data
// is borrowed for the duration of the call; false cancels subsequent work.
class OmniSession {
 public:
  OmniSession();~OmniSession();OmniSession(const OmniSession&)=delete;OmniSession& operator=(const OmniSession&)=delete;
  bool open(const std::string& bundle,const std::string& expected_package_id,std::string& error,const OmniBundlePolicy& policy={});
  bool respondText(const OmniRequest& request,const OmniOptions& options,
                   const std::function<bool(std::string_view)>& on_text,OmniResult& result,
                   const std::function<void(int32_t,size_t)>& on_token={});
  bool respondSpeech(const OmniRequest& request,const OmniOptions& options,
                     const std::function<bool(std::string_view)>& on_text,
                     const std::function<bool(const float*,size_t,int32_t)>& on_pcm,OmniResult& result);
  std::string packageId()const;bool usesReferenceAssets()const;
 private:struct Impl;std::unique_ptr<Impl> impl_;
};
}
