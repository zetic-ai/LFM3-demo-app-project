#pragma once
#include <cstddef>
#include <string>
namespace lfm3_ios {
struct VisionBundlePolicy {
  // Opt-in requires both the exact trusted package ID and the provenance file
  // SHA; it does not assert numerical parity or quality for the new graphs.
  bool allow_explicit_vision_assets=false;
  std::string expected_provenance_sha256;
};
struct VisionBundleInfo {std::string package_id; size_t prefill_rows=0,context_rows=0; bool reference_vision_assets=false;};
// Package identity is a digest, not a signature; caller supplies a trusted ID
// and keeps the directory immutable throughout use.
bool verifyVisionBundle(const std::string& directory,const std::string& expected_package_id,
                        VisionBundleInfo& info,std::string& error,
                        const VisionBundlePolicy& policy={});
}
