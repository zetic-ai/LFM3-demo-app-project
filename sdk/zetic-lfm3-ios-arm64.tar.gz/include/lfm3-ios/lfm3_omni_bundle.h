#pragma once
#include <cstddef>
#include <string>
namespace lfm3_ios {
struct OmniBundlePolicy {
  // New ZTC-free export is explicitly opted in with its trusted provenance
  // digest as well as its exact package ID; this does not assert quality.
  bool allow_explicit_export=false;
  std::string expected_provenance_sha256;
};
struct OmniBundleInfo {std::string package_id;size_t prefill_rows=0,context_rows=0;bool reference_assets=false;};
// The caller supplies a trusted exact package ID and keeps the bundle immutable.
bool verifyOmniBundle(const std::string& root,const std::string& expected_package_id,
                      OmniBundleInfo& info,std::string& error,const OmniBundlePolicy& policy={});
}
