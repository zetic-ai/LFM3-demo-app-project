#pragma once
#include "text_generation.h"

namespace lfm3_ios {
enum class ChatRole { System, User, Assistant, Tool };
struct ChatMessage { ChatRole role; std::string text; };
struct ChatInput {
  std::string system;
  std::vector<ChatMessage> history;
  std::string user;
};
// Implements Ixian LfmTemplate::assemble(Simple), including an empty system
// turn. The input is text-only; media/tools declarations are not supported.
bool renderTextChat(const ChatInput& input, std::string& output, std::string& error);
// Special tokens are parsed and the model BOS is inserted once, as in the
// measured Ixian path; EOS is not appended to the input.
bool encodeTextChat(TextTokenizer& tokenizer, const ChatInput& input,
                    std::vector<int32_t>& ids, std::string& error);
// <|im_end|> is the required special EOS token, as in Ixian's HF tokenizer.
bool generateChat(TextSession& session, TextTokenizer& tokenizer,
                  const ChatInput& input, size_t max_tokens,
                  const std::vector<std::string>& stop_strings,
                  const std::function<bool(std::string_view)>& on_chunk,
                  size_t& generated, std::string& error,
                  const std::function<void(int32_t, size_t)>& on_token = {});
}
