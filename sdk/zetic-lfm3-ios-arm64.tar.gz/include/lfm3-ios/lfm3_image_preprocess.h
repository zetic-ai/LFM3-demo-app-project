#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace zetic_mlange::lm::diagnostic {

struct Lfm3ImageOptions {
  // Explicit export bucket, not HF's default aspect-preserving smart_resize.
  int output_width = 512;
  int output_height = 512;
};

struct Lfm3ImagePixels {
  int encoded_width = 0, encoded_height = 0;
  int source_width = 0, source_height = 0;  // After EXIF orientation.
  int output_width = 0, output_height = 0;
  int exif_orientation = 1;
  std::vector<uint8_t> rgb;  // Oriented, resized RGB8 HWC.
};

// Local, single-frame JPEG/PNG decoder. Run on a background thread. Applies
// all eight EXIF orientations, discards straight alpha as PIL convert("RGB")
// does, and uses the same antialiased bicubic RGB8 resize as the video path.
// Supports 8-bit RGB/gray images; unsupported formats fail explicitly.
bool decodeImageLfm3(const std::string& path, const Lfm3ImageOptions& options,
                     Lfm3ImagePixels* pixels, std::string* error);

}  // namespace zetic_mlange::lm::diagnostic
