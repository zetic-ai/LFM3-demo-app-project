#pragma once
#include "lfm3_omni_session.h"
namespace lfm3_ios {
// Opt-in, text-to-speech-only resident benchmark session. Preloads every model;
// uses more memory than staged OmniSession. Not reentrant. A failed request
// invalidates the session and requires open() again; cancellation is reusable.
class OmniResidentSpeechSession {
 public:
  OmniResidentSpeechSession();~OmniResidentSpeechSession();
  OmniResidentSpeechSession(const OmniResidentSpeechSession&)=delete;
  OmniResidentSpeechSession& operator=(const OmniResidentSpeechSession&)=delete;
  bool open(const std::string& bundle,const std::string& expected_package_id,
            std::string& error,const OmniBundlePolicy& policy={},
            const OmniOptions& preload_observers={});
  bool respond(const OmniRequest& request,const OmniOptions& options,
               const std::function<bool(std::string_view)>& on_text,
               const std::function<bool(const float*,size_t,int32_t)>& on_pcm,
               OmniResult& result);
  std::string packageId()const;
 private: struct Impl;std::unique_ptr<Impl> impl_;
};
}
