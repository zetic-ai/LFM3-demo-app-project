#pragma once
#include <chrono>
#include <cstdint>
#include <functional>
namespace lfm3_ios {
using ModelLoadObserver = std::function<void(const char*, uint64_t, uint64_t)>;
inline uint64_t monotonicNanoseconds() {
  return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::steady_clock::now().time_since_epoch()).count());
}
class ModelLoadTimer {
 public:
  ModelLoadTimer(const ModelLoadObserver& observer, const char* name)
      : observer_(observer), name_(name), start_(observer ? monotonicNanoseconds() : 0) {}
  ~ModelLoadTimer() noexcept { if (observer_) { const auto end=monotonicNanoseconds();
      try { observer_(name_, start_, end); } catch (...) {} } }
 private:
  const ModelLoadObserver& observer_; const char* name_; uint64_t start_;
};
}
