#pragma once
#include "text_generation.h"
#include "lfm3_vision_bundle.h"
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <vector>
namespace lfm3_ios {
struct VisionPrompt {
  std::string prefix_text;
  std::string suffix_text;
};
// Matches the measured single-user image/video chat template with thinking off.
VisionPrompt visionQuestionPrompt(const std::string& question);
std::string renderVisionImagePrompt(const VisionPrompt& prompt);
bool renderVisionVideoPrompt(const VisionPrompt& prompt,const std::vector<double>& timestamps,
                             std::string& output,std::string& error);
struct VisionTextOptions {
  size_t max_tokens=256;
  bool stop_at_eos=true;
  std::vector<std::string> stop_strings;
  // Four sampled frames, or 0 for the HF 2 fps policy (up to 768). The fixed
  // prefill capacity still limits how many groups can be accepted.
  size_t num_video_frames=4;
  double sample_fps=0, metadata_fps_override=0;
};
struct VisionTextResult {
  size_t generated=0,prompt_rows=0,vision_groups=0;
  GenerationFinish finish=GenerationFinish::TokenLimit;
  std::vector<size_t> sampled_frame_indices;
  double frontend_seconds=0,preprocess_seconds=0,encoder_seconds=0;
};
// Text and vision modules are loaded from one validated, immutable VL bundle.
// All methods are synchronous and non-reentrant; call on a worker thread.
class VisionTextSession {
 public:
  VisionTextSession();~VisionTextSession();
  VisionTextSession(const VisionTextSession&)=delete;
  VisionTextSession& operator=(const VisionTextSession&)=delete;
  bool open(const std::string& bundle,const std::string& expected_package_id,std::string& error);
  bool open(const std::string& bundle,const std::string& expected_package_id,
            const VisionBundlePolicy& policy,std::string& error);
  bool generateImage(const std::string& image_path,const VisionPrompt& prompt,const VisionTextOptions& options,
                     const std::function<bool(std::string_view)>& on_chunk,VisionTextResult& result,std::string& error,
                     const std::function<void(int32_t,size_t)>& on_token={});
  bool generateVideo(const std::string& video_path,const VisionPrompt& prompt,const VisionTextOptions& options,
                     const std::function<bool(std::string_view)>& on_chunk,VisionTextResult& result,std::string& error,
                     const std::function<void(int32_t,size_t)>& on_token={});
  std::string packageId() const; TextRoute selectedRoute() const;
  bool usesReferenceVisionAssets() const;
 private:
  struct Impl;std::unique_ptr<Impl> impl_;
};
}
