#pragma once
#include <cstddef>
#include <string>
namespace lfm3_ios {
struct AudioBundleInfo { std::string package_id; size_t prefill_rows=0, context_rows=0; };
// Verifies all bundle hashes and checks the pinned Audio source, stage
// provenance, exact selected-FP16 mixed recipe, module names and suppression.
// expected_package_id must come from a trusted release record. It is a digest,
// not a signature. The directory must stay immutable for the session lifetime.
bool verifyAudioBundle(const std::string& directory, const std::string& expected_package_id,
                       AudioBundleInfo& info, std::string& error);
}
