#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include <string_view>
#include <vector>

namespace lfm3_ios {

// HF tokenizer.json adapter and incremental UTF-8 detokenizer. The class is
// synchronous and non-reentrant. Callers loading a model bundle should verify
// its manifest before passing the tokenizer file path.
class TextTokenizer {
 public:
  TextTokenizer();
  ~TextTokenizer();
  TextTokenizer(const TextTokenizer&) = delete;
  TextTokenizer& operator=(const TextTokenizer&) = delete;

  bool load(const std::string& tokenizer_json, std::string& error);
  bool encode(std::string_view text, bool parse_special,
              std::vector<int32_t>& ids, std::string& error) const;
  // Begin a fresh incremental output. Stop strings are withheld from chunks.
  bool beginDecode(const std::vector<std::string>& stop_strings, std::string& error);
  bool push(int32_t id, std::string& chunk, bool& stopped, std::string& error);
  bool finish(std::string& chunk, std::string& error);
  bool decode(const std::vector<int32_t>& ids, std::string& output,
              std::string& error) const;
  bool specialTokenId(const std::string& token, int32_t& id, std::string& error) const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};
}  // namespace lfm3_ios
