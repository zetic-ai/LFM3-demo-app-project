#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace zetic_mlange::lm::diagnostic {

// Explicit fixed export bucket. Four frames is an intentional workload limit;
// the HF processor's default is 2 fps with 4..768 sampled frames.
struct Lfm3VideoOptions {
  size_t num_frames = 4;
  double sample_fps =
      0.0;  // Used only when num_frames == 0; 0 selects HF 2 fps.
  int output_width = 512;
  int output_height = 512;
  double metadata_fps_override = 0.0;
};

struct Lfm3VideoFrame {
  size_t source_index = 0;
  double presentation_seconds = 0.0;
  std::vector<uint8_t>
      rgb;  // Resized RGB8 HWC, output_width * output_height * 3.
};

struct Lfm3VideoFrames {
  int source_width = 0;  // Display-oriented width, after preferredTransform.
  int source_height = 0;
  int output_width = 0;
  int output_height = 0;
  size_t total_frames = 0;
  double metadata_fps = 0.0;  // Used for HF index/fps prompt timestamps.
  double nominal_fps = 0.0;
  double duration_seconds = 0.0;
  std::vector<Lfm3VideoFrame> frames;
};

// Pure sampler: HF linspace(...).round() with round-to-nearest/ties-to-even.
// Throws on invalid metadata or unsupported counts. Explicit num_frames can
// repeat indices for clips shorter than the requested frame count, as HF does.
std::vector<size_t> sampleVideoFrameIndicesLfm3(
    size_t total_frames, double metadata_fps, const Lfm3VideoOptions& options);

// Antialiased separable bicubic (a=-0.5), with byte rounding after each axis.
// The same resized bytes must be supplied to both inference engines.
std::vector<uint8_t> resizeVideoRgbLfm3(const uint8_t* rgb, int width,
                                        int height, int output_width,
                                        int output_height);

// AVFoundation local-file decoder; synchronous, call on a worker thread.
bool decodeVideoLfm3(const std::string& path, const Lfm3VideoOptions& options,
                     Lfm3VideoFrames* frames, std::string* error);

// Pair i means frames[2*i], frames[2*i+1]; repeat the final frame if odd.
// Output is FP32 unnormalized RGB in [0,255], [2,3,H,W], for Core ML preproc.
std::vector<float> packVideoPairLfm3(const Lfm3VideoFrames& frames,
                                     size_t pair_index);

// Match HF: average first/last source index in each pair / round(fps,6).
std::vector<double> videoPairTimestampsLfm3(const Lfm3VideoFrames& frames);

}  // namespace zetic_mlange::lm::diagnostic
