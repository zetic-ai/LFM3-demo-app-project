// Quickstart: one streamed chat turn and a follow-up on the Hexagon NPU (ZeticMLange Hexagon SDK).
//   quickstart <model dir> ["prompt"] [image.png | clip.wav ...]
// Media (LFM3-VL / Audio / Omni packages): images must be exactly 512 x 512 RGB — the SDK does not resize, letterbox or
// tile; do that before passing them. Audio: WAV / PCM at any rate (resampled to 16 kHz), up to 30 s per clip.
#include <cstdio>
#include <string>

#include <zetic_llm.h>

using namespace zetic::mlange;

int main(int argc, char** argv) {
  if (argc < 2) return fprintf(stderr, "usage: %s <model dir> [prompt]\n", argv[0]), 2;
  try {
    LLM llm = LLM::fromPath(argv[1]);
    printf("%s on %s (v%d, %d NSP)\n", llm.info().model_id.c_str(), llm.info().soc.c_str(), llm.info().hexagon_arch,
           llm.info().nsp_count);
    std::vector<Part> parts;
    for (int i = 3; i < argc; ++i) {  // media first, in order, then the text (as the HF processors place them)
      const std::string f = argv[i];
      if (f.size() > 4 && f.compare(f.size() - 4, 4, ".wav") == 0) parts.push_back(Part::Aud(Audio::fromWav(f)));
      else parts.push_back(Part::Img(Image::fromFile(f)));  // PNG / JPEG / PPM; must be 512 x 512
    }
    parts.push_back(Part::Text(argc > 2 ? argv[2] : "What is the capital of France?"));
    std::vector<Message> history{Message::User(std::move(parts))};
    auto print = [](const StreamEvent& ev) {
      if (ev.type == StreamEvent::Type::Text) fwrite(ev.text.data(), 1, ev.text.size(), stdout), fflush(stdout);
      return true;
    };
    Response r = llm.chat(history, {}, print);
    if (r.status != Status::Ok) return fprintf(stderr, "error (%s): %s\n", statusName(r.status), r.error.c_str()), 1;
    printf("\nTTFT %.1f ms, %.1f t/s, finish %s\n", r.timings.ttft, r.timings.tokens_per_second, finishReasonName(r.finish_reason));
    history.push_back(r.message);  // the follow-up reuses the cached prefix
    history.push_back(Message::User("And its population?"));
    Response r2 = llm.chat(history, {}, print);
    printf("\nTTFT %.1f ms (cached %d of %d rows)\n", r2.timings.ttft, r2.usage.cached_rows, r2.usage.prompt_rows);
  } catch (const Error& e) {
    fprintf(stderr, "error: %s\n", e.what());
    return 1;
  }
  return 0;
}
