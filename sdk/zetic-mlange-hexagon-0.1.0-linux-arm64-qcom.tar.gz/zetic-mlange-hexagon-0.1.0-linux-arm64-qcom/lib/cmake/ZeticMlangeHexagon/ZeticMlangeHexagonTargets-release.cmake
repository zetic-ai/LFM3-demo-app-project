#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "zetic::mlange_hexagon" for configuration "Release"
set_property(TARGET zetic::mlange_hexagon APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zetic::mlange_hexagon PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzetic_mlange_hexagon.so"
  IMPORTED_SONAME_RELEASE "libzetic_mlange_hexagon.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zetic::mlange_hexagon )
list(APPEND _IMPORT_CHECK_FILES_FOR_zetic::mlange_hexagon "${_IMPORT_PREFIX}/lib/libzetic_mlange_hexagon.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
