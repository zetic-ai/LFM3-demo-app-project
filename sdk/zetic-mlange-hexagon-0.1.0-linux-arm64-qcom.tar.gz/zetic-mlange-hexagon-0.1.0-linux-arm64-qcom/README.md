# ZeticMLange Hexagon SDK (v0.1, preview)

The LFM3 family on the Qualcomm Hexagon NPU through **Ixian Hexagon**, ZETIC's own Hexagon runtime. There is no QNN and no llama.cpp in it.
The design is in [DESIGN.md](DESIGN.md).

| Device | SoC | Target dir | SDK tarball |
|---|---|---|---|
| Galaxy S25 | SM8750 | `v79` | `zetic-mlange-hexagon-0.1.0-android-arm64` |
| Xiaomi 17 Ultra, Galaxy S26 Ultra | SM8850 | `v81` | `zetic-mlange-hexagon-0.1.0-android-arm64` |
| Dragonwing IQ9 (2 NSP) | QCS9075 | `v73` | `zetic-mlange-hexagon-0.1.0-linux-arm64-qcom` |

**Status of this build (phases 1 and 2):**
- Works: text chat with LFM3-1.7B (streaming, sampling, stop strings, cancel, and multi-turn with the prefix cache).
- Works (phase 2): image and audio input for LFM3-VL-2B, LFM3-Audio-2B (ASR) and LFM3-Omni-2B, several media per
  message, Omni image + audio in one turn ([Images and audio](#images-and-audio-lfm3-vl-2b-lfm3-audio-2b-lfm3-omni-2b)).
  **Images must be exactly 512 x 512 RGB** (the SDK does not resize).
- Works (phase 2): video input on LFM3-VL-2B / Omni from 512 x 512 frames the app supplies (2 fps sampling and
  temporal patches as HF).
- Next version (not in 0.1.0): speech output for LFM3-Audio-2B / Omni-2B — TTS (`modalities {Audio}`) and voice chat
  (`{Text, Audio}`, text or audio in), streamed as 24 kHz PCM ([Speech output](#speech-output-lfm3-audio-2b-lfm3-omni-2b)).
  It needs packages exported with `capabilities.speech_out = true`; the 0.1.0 packages say false and the SDK then
  returns `Status::Unsupported` for an `{Audio}` reply.
- d1 `Decision` (d1-2B, d1-Omni-2B): `systemOne` / `systemOneBatch` / `probabilities` with noul, choice (also `multiple`) and
  score questions, text or JSON states, images and (d1-Omni) audio clips, and `runRaw`. Typed questions (text / number / date / box)
  and video come in v0.2.

## Run in 2 minutes (Android, no build)

```bash
adb push zetic-mlange-hexagon-0.1.0-android-arm64/. /data/local/tmp/zsdk/
adb push models/lfm3-1.7b/v81 /data/local/tmp/zsdk/models/lfm3-1.7b/
adb shell 'cd /data/local/tmp/zsdk && LD_LIBRARY_PATH=lib bin/zetic_lfm3_cli info --model models/lfm3-1.7b --verify'
adb shell 'cd /data/local/tmp/zsdk && LD_LIBRARY_PATH=lib bin/zetic_lfm3_cli chat --model models/lfm3-1.7b "What is the capital of France?"'
```

On the IQ9 the steps are the same, using `scp` / `ssh`. The skel there is `lib/libhexrt_v73_skel.so`.

The DSP skels are named per arch, `libhexrt_v<arch>_skel.so` (as QNN's `libQnnHtpV<arch>Skel.so`), and sit in `lib/` next to the
library. The library finds the one for this device's cDSP there and adds that directory to `ADSP_LIBRARY_PATH`.

## Build your app

```cmake
find_package(ZeticMlangeHexagon 0.1 CONFIG REQUIRED)   # -DCMAKE_PREFIX_PATH=<sdk>/lib/cmake
target_link_libraries(my_app PRIVATE zetic::mlange_hexagon)
```

```cpp
#include <zetic_llm.h>
using namespace zetic::mlange;

LLM llm = LLM::fromPath("/data/local/tmp/zsdk/models/lfm3-1.7b");      // picks v79 / v81 / v73 for this device
std::vector<Message> history{Message::User("What is the capital of France?")};
Response r = llm.chat(history, {}, [](const StreamEvent& ev) {
  if (ev.type == StreamEvent::Type::Text) fwrite(ev.text.data(), 1, ev.text.size(), stdout);
  return true;                                                         // false stops the reply
});
history.push_back(r.message);                                          // follow-ups reuse the cached prefix
history.push_back(Message::User("And its population?"));
Response r2 = llm.chat(history);
```

In an Android app, put `libzetic_mlange_hexagon.so`, `libc++_shared.so`, `libhexrt_v79_skel.so` and `libhexrt_v81_skel.so` in one
`jniLibs/arm64-v8a/` directory, keep them extracted on install (`packaging { jniLibs { useLegacyPackaging = true } }`), and pass
`applicationInfo.nativeLibraryDir` as `LLMOptions::native_lib_dir` (`Decision::Options::native_lib_dir` for d1).

The Android libraries and CLIs are 16 KB page-size compatible (every LOAD segment aligned 0x4000; Android 15+ / Google Play requirement); the DSP skels are Hexagon ELFs and not affected.

A full example is in [examples/quickstart](examples/quickstart).

### d1 decisions

```cpp
#include <zetic_decision.h>
using namespace zetic::mlange;

Decision d1 = Decision::fromPath("/data/local/tmp/zsdk/models/d1-2b");
DecisionResult out = d1.systemOne(State::Text("I was charged twice and my parcel never arrived. Please refund one charge."), {
    {"refund",  Question::Noul("Is the customer asking for a refund?")},
    {"team",    Question::Choice("Which team should handle this?", {{"billing", "Charges, refunds, invoices"},
                                                                    {"shipping", "Delivery and parcels"}})},
    {"urgency", Question::Score("How urgent is this ticket?", {"low", "medium", "high"})}});
// out.answers[0].second.noul = P(yes); answers[1].second.choice = "billing"; answers[2].second.legend = "medium"
```

All questions on one state go through one NPU pass (up to 16 per pass, the model's `d1_set_size`). Images and clips are
`Part::Img(Image::fromRgb(...))` / `Part::Aud(Audio::fromWav(...))` in the third argument; they are encoded once per request.
`bin/zetic_d1_cli demo --model <d1 package>` runs the example above.

- **Default sampling:** the model's generation config (temperature 0.1, top-k 50, repetition penalty 1.1), sampled on the CPU.
- **Greedy:** set `GenerationConfig::temperature = 0`. Greedy takes the NPU's argmax and never reads the logits.

## Images and audio (LFM3-VL-2B, LFM3-Audio-2B, LFM3-Omni-2B)

```cpp
#include <zetic_llm.h>
using namespace zetic::mlange;

LLM vl = LLM::fromPath("models/lfm3-vl-2b");                       // or lfm3-omni-2b
GenerationConfig greedy; greedy.temperature = 0;
Response r = vl.chat({Message::User({Part::Img(Image::fromFile("cats.png")),   // must be 512 x 512
                                     Part::Text("How many cats are in the image?")})}, greedy);

LLM asr = LLM::fromPath("models/lfm3-audio-2b");
Response t = asr.chat({Message::System("Perform ASR in English."),
                       Message::User({Part::Aud(Audio::fromWav("jfk.wav"))})}, greedy);

// Omni: several media in one turn, in prompt order
LLM omni = LLM::fromPath("models/lfm3-omni-2b");
Response o = omni.chat({Message::User({Part::Img(Image::fromFile("cats.png")), Part::Aud(Audio::fromWav("jfk.wav")),
                                       Part::Text("Describe the image, then repeat what the speaker says.")})}, greedy);
```

**Image size: exactly 512 x 512 RGB.** The SDK does no resolution handling — no resize, letterbox or tiling — because
that choice changes both accuracy and speed and belongs to the app. `Image::fromFile` decodes PNG / JPEG / PPM / BMP
(stb_image) only to get the pixels; a request with an image (or video frame) of any other size returns
`Status::InvalidArgument` with "images must be exactly 512x512 RGB". Resize / letterbox / crop before passing it.

- **Audio:** `Audio::fromWav` reads PCM 8 / 16 / 24 / 32-bit and float WAV, mixes to mono and resamples to 16 kHz
  (windowed sinc); `Audio::fromPcm` takes float samples at any rate. One audio part holds up to 30 s (the encoder's
  window); split longer audio into several parts.
- **Where media go:** parts are placed in the prompt in the order given. LFM3-VL / Omni wrap each image (Omni: also each
  clip) in `<|vision_start|> … <|vision_end|>` as their HF chat templates do; LFM3-Audio-2B takes the clip's rows bare.
- **Several media per message** work on every media model (Omni: images and clips mixed), bounded only by the context
  (an image is 256 rows, a 30 s clip 375 rows, of 2,048 by default; see [Context length](#context-length)).
- **Follow-up turns** re-send the whole history; the prefix cache keeps the media rows, so a text follow-up after an
  image turn does not re-encode or re-prefill the image (`Response::usage.cached_rows`). After a cache miss (an edited
  turn) the last 8 encoded media are reused from an encoder-output cache instead of re-running the encoder.
  `GenerationConfig::cache_prompt = false` turns both caches off (benchmarks).
- **Video** (`Part::Vid(Video::fromFrames(frames, fps))`, LFM3-VL / Omni): decoded frames, each exactly 512 x 512 RGB
  (the app decodes the container and letterboxes / resizes; the SDK has no ffmpeg). With the clip's `fps` (or one
  timestamp per frame) the SDK samples 2 fps as the HF processor (`GenerationConfig::video`), pairs frames into temporal
  patches (2 frames -> 256 rows) and adds HF's `<t seconds>` markers; without them it takes the frames as given. A patch
  costs ~264 of the 2,048 default positions, so about 6 patches (6 s at 2 fps) fit with a 256-token answer (more with a larger
  `max_context`);
  `GenerationConfig::video.max_groups` samples a longer clip down to that many patches.
- **CLI:** `zetic_lfm3_cli chat --model models/lfm3-vl-2b --media cats.png "How many cats?"`
  (`--media a.png+b.wav` for several; a directory of frames is a video, `--video-fps 24`), `eval vl5 | asr | omni5 | mt | video --data <dir>`, `bench vl | asr | asr30 | ia`
  (`--ab-module <hexrt_mm>` runs the module tool on the same prompt in the same session).

## Speech output (LFM3-Audio-2B, LFM3-Omni-2B)

OpenAI chat-completions style: ask for audio in `GenerationConfig::modalities`; the reply streams `StreamEvent::Type::Audio`
events (mono float PCM at `Capabilities::speech_sample_rate`, 24 kHz) and returns the whole clip in `Response::audio`.

```cpp
LLM m = LLM::fromPath("models/lfm3-audio-2b");                      // or lfm3-omni-2b; capabilities().speech_out
GenerationConfig tts;
tts.modalities = {Modality::Audio};                                 // TTS: the user text is spoken
Response r = m.chat({Message::System("Perform TTS in American English using a female voice."),
                     Message::User("The quick brown fox jumps over the lazy dog.")}, tts,
                    [](const StreamEvent& ev) {
                      if (ev.type == StreamEvent::Type::Audio) play(ev.audio->pcm, ev.audio->samples);  // 24 kHz
                      return true;
                    });
// r.audio: the whole clip; r.timings.first_audio / realtime_factor; r.usage.audio_frames (80 ms each)

GenerationConfig voice;
voice.modalities = {Modality::Text, Modality::Audio};               // voice chat: interleaved text + speech
Response v = m.chat({Message::System("Respond with interleaved text and audio."),
                     Message::User({Part::Aud(Audio::fromWav("question.wav"))})}, voice, on_event);
```

- **Modes:** `{Audio}` = TTS (the prompt ends with `<|audio_start|>`), `{Text, Audio}` = interleaved reply
  (`<|mixed_start|>`: text and speech in turns of 6 tokens / 12 frames, then speech only after the text ends). The
  system prompts above are the ones the models were trained with for these modes. Text and audio input work as in any
  request (voice chat from a WAV, Omni with an image too).
- **Streaming:** the first `Audio` event comes after `audio.first_chunk_frames` frames (default 1 = 80 ms of speech),
  then one event per `audio.chunk_frames` (default 12 = 0.96 s, one codec call). `AudioChunk::first_sample` is the
  chunk's position in the reply; the last event has `last = true`. Text pieces of a voice reply arrive as `Text` events
  in between. The chunking changes when audio arrives, not what the model generates.
- **Sampling:** the speech codebooks use the model's generation config (Audio-2B temperature 1.0 / top-k 128 /
  repetition penalty 1.1 over 4,096 frames; Omni 0.4 / all codes / 1.2 over 64), overridable in `AudioOutputConfig`;
  `GenerationConfig::seed` (non-zero) makes a reply reproducible. The text of a voice reply uses the usual text
  settings (the packages' default is greedy).
- **Length:** `max_audio_seconds` (default 30) bounds the frames, `max_tokens` the text of a voice reply; both count
  against the context (`max_context`, default 2,048 positions; `Status::ContextExceeded` up front, `FinishReason::Length` when reached).
- **Stop / cancel:** returning `false` from the callback or `cancel()` ends the reply after the current frame; the
  frames already generated are still decoded and delivered (`last = true`), and the partial reply stays in the cache.
- **Multi-turn:** send `Response::message` back in the history: the reply's frames stay in the prefix cache and the
  follow-up prefills only the new turn. An edited speech reply is re-read as plain text.
- **Not available with audio output:** `logprobs` (`Status::Unsupported`).
- **CLI:** `zetic_lfm3_cli chat --model models/lfm3-audio-2b --tts --out reply.wav "Hello there."`,
  `--voice --media question.wav --out reply.wav`; `bench tts | voice --ab-module <hexrt_mm>` (first audio, real-time
  factor, codes and WAV against the module tool).

## Context length

`LLMOptions::max_context` is the number of positions a loaded model holds: every prompt row (text, image, audio, video),
every reply row and the earlier turns kept in the prefix cache.

| Target | `max_context = 0` (default) | Largest `max_context` |
|---|---:|---:|
| Phones (v79 / v81, one NSP) | 2,048 | 4,096 |
| IQ9 (v73, two NSPs) | 2,048 | 131,072 |

- `0`, or any value up to 2,048, keeps the package's 2,048-position KV cache exactly as before (a smaller value only lowers the bound).
- A value above 2,048 switches the runtime to its long-context mode at load (rounded up to a multiple of 64): the KV cache
  gets buffers of its own instead of the package's, so the same packages work; no re-export. On the IQ9 the KV heads are
  split over the two NSPs. A value above the target's limit fails at load with `Status::InvalidArgument`.
- Cost: more memory for the KV cache (12 KB per position plus ~45 MB of fixed buffers: ~48 MB more than the default at
  4,096, ~0.4 GB at 32,768, ~1.6 GB at 131,072), and
  TTFT and decode speed depend on the depth actually used. Set it only as large as the app needs.
- d1 decision models (`Decision`) keep their single pass of up to `prefill_rows` rows.
- CLI: `--ctx <positions>` on any command, e.g. `zetic_lfm3_cli chat --model models/lfm3-1.7b --ctx 4096 --user-file long.txt`.

## Building the SDK

```bash
sdk/build.sh --android-arm64 [--tarball]     # NDK r26d, c++_shared; skels v79 + v81 (Hexagon SDK + tools = build_infra's pin, 6.7.0.0 + 21.0.04; SDK_HEX overrides)
sdk/build.sh --qcom-linux-arm64 [--tarball]  # Qualcomm OE eSDK via build_infra scripts/lib/qcom-env.sh; skel v73
sdk/build.sh --host                          # x86 unit tests (template ids vs HF, d1 renderer goldens, media, stop, sampler)
```

**Model packages:** `sdk/export/export_assets.py` builds them from the existing Ixian Hexagon packs. It does no conversion (DESIGN.md §4).

## Limits (v0.1)

- 2,048 positions by default; up to 4,096 on phones and 131,072 on the IQ9 with `LLMOptions::max_context` ([Context length](#context-length)).
- One active model per process.
- The CLI and the native library are tested from `adb shell` and `ssh` only. An Android app process is not validated yet.

## Licenses

- tokenizers-cpp (Apache-2.0), with the HF `tokenizers` Rust crate inside it.
- nlohmann/json (MIT).
- stb_image v2.30 (public domain / MIT), image file decoding.
- The LFM3 weights are under the LFM Open License v1.0.
- The DSP skel and the FastRPC stub are built with the Qualcomm Hexagon SDK. See `PROVENANCE.json`.
